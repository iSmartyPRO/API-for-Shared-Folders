module.exports = {
    APP_PORT: 3000,
    APP_NAME: "Folder Share API",
    credential: {
      username: "GENCO\\gencoadmin",
      password: "Genc0Adm1no!"
    },
    api: [
      {
        name: "ilias-test",
        token: "Te8xd4FPw9S48mCVWv7qna" // длина торкена должна быть равна 22
      }
    ],
    shares: [
      {
        name: "PC038Share",
        computername: "PC-038",
        shareName: "shara$",
        path: "D:\\share",
        FullAccess: "GENCO\\Пользователи домена",
        description: "Тестовая шара"
      },
      {
        name: "PC038Projects",
        computername: "PC-038",
        shareName: "projects$",
        path: "D:\\Projects",
        FullAccess: "Все",
        description: "Шара проектов"
      }
    ]
  }